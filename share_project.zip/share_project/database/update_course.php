<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

ob_start();
session_start();
include 'connection.php';
if(isset($_POST['submit'])){
    $course_id = $_POST['id'];
    $link = $_POST['link'];
    $name = $_POST['name'];
    $sql = "UPDATE courses SET link = '$link', name = '$name' WHERE id = $course_id";
    if(mysqli_query($conn, $sql)){
        header("Location: ../index.php?success=3");
    }else{
        header("Location: ../index.php?error=1");
    }
}
?>