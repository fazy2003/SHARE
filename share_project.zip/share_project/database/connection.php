<?php
    $conn = mysqli_connect("localhost", "root", "", "shareproject");
    if(!$conn){
        die("Connection failed: ".mysqli_connect_error());
    }

?>