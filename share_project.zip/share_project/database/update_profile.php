<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

ob_start();
session_start();
include 'connection.php';
if(isset($_POST['submit'])){
    $user_id = $_POST['user_id'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $phone = $_POST['phone'];
    $student_id = $_POST['student_id'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if($password != $confirm_password){
        header("Location: ../profile.php?error=2");
        exit();
    }
    
    $sql = "UPDATE users SET first_name = '$first_name', last_name = '$last_name', phone = '$phone', student_id = '$student_id', password = '$password' WHERE id = $user_id";
    if(mysqli_query($conn, $sql)){
        header("Location: ../profile.php?success=1");
    }else{
        header("Location: ../profile.php?error=1");
    }
    
}
?>