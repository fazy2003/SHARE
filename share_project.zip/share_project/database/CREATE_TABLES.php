<?php
    include 'connection.php';
    //create users table
    $sql = "CREATE TABLE users(
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        first_name VARCHAR(30) NOT NULL,
        last_name VARCHAR(30) NOT NULL,
        email VARCHAR(50) NOT NULL,
        phone VARCHAR(256) NOT NULL,
        student_id VARCHAR(20) NOT NULL,
        password VARCHAR(50) NOT NULL,
        reg_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )";
    if(mysqli_query($conn, $sql)){
        echo "Table created successfully";
    }else{
        echo "Error: ".$sql."<br>".mysqli_error($conn);
    }

    //create courses table
    //id, link, name, uploaded by, uploaded on
    $sql = "CREATE TABLE courses(
        id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        link VARCHAR(256) NOT NULL,
        name VARCHAR(256) NOT NULL,
        uploaded_by INT(6) NOT NULL,
        uploaded_on TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )";
    if(mysqli_query($conn, $sql)){
        echo "Table created successfully";
    }else{
        echo "Error: ".$sql."<br>".mysqli_error($conn);
    }

?>