<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
    
    ob_start();
    session_start();
    include 'connection.php';
    if(isset($_POST['submit'])){
        $email = $_POST['email'];
        $password = $_POST['password'];
        $sql = "SELECT * FROM users WHERE email = '$email' AND password = '$password'";
        $result = mysqli_query($conn, $sql);
        if(mysqli_num_rows($result) > 0){
            $row = mysqli_fetch_assoc($result);
            $_SESSION['username'] = $row['first_name'] . " " . $row['last_name'];
            $_SESSION['id'] = $row['id'];
            header("Location: ../index.php");
        }else{
            header("Location: ../login.php?error=1");
        }
    }

?>
