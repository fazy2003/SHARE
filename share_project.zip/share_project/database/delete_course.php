<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

ob_start();
session_start();
include 'connection.php';
if(isset($_GET['id'])){
    $course_id = $_GET['id'];
    $sql = "DELETE FROM courses WHERE id = $course_id";
    if(mysqli_query($conn, $sql)){
        header("Location: ../index.php?success=2");
    }else{
        header("Location: ../index.php?error=1");
    }
}

?>