<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

ob_start();
session_start();
include 'connection.php';
//link,name,uploaded_by
if(isset($_POST['submit'])){
    $link = $_POST['link'];
    $name = $_POST['name'];
    $uploaded_by = $_POST['uploaded_by'];
    $sql = "INSERT INTO courses (link, name, uploaded_by) VALUES ('$link', '$name', '$uploaded_by')";
    if(mysqli_query($conn, $sql)){
        header("Location: ../index.php?success=1");
    }else{
        header("Location: ../index.php?error=1");
    }
}

?>