<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);

ob_start();
session_start();
include 'connection.php';
if(isset($_POST['submit'])){
    $user_id = $_POST['user_id'];
    $sql = "DELETE FROM users WHERE id = $user_id";
    if(mysqli_query($conn, $sql)){
        session_destroy();
        header("Location: ../login.php?success=2");
    }else{
        header("Location: ../profile.php?error=1");
    }   
}

?>