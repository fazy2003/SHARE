<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
    include 'connection.php';
    if(isset($_POST['submit'])){
        $first_name = $_POST['first_name'];
        $last_name = $_POST['last_name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $student_id = $_POST['student_id'];
        $password = $_POST['password'];

        if($password != $_POST['confirm_password']){
            header("Location: ../register.php?error=password");
            exit();
        }
        $sql = "INSERT INTO users (first_name, last_name, email, phone, student_id, password) 
        VALUES ('$first_name', '$last_name', '$email', '$phone', '$student_id', '$password')";
        if(mysqli_query($conn, $sql)){
            header("Location: ../login.php?success=1");
        }else{
            header("Location: ../register.php?error=sql_error");
        }
    }

?>